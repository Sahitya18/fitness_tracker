package com.fittrack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FitTrackerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(FitTrackerAppApplication.class, args);
	}

}
