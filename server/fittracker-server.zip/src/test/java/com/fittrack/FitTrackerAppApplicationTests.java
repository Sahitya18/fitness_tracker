package com.fittrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FitTrackerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
